from reader import read_col

filename = "captains.txt"
col_name1 = "name"
col_name2 = "tied"
names_col = read_col(filename, col_name1, str)
tied_col = read_col(filename, col_name2, str)

last_value = tied_col[0]
captain_index = 0
count = 0
for tiedMatches in tied_col:
    if tiedMatches > last_value:
        captain_index = count
    last_value = tiedMatches
    count += 1
print(names_col[captain_index], "has highers number of tied matches")
