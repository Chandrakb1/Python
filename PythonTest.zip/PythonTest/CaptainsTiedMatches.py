from reader import read_col

filename = "captains.txt"
col_name="tied"

tied_col = read_col(filename, col_name, str)

def findCaptainsTiedMatches(matches):
    count = 0
    for tiedMatches in matches:
        if tiedMatches > '0':
            count += 1
    return count

count=findCaptainsTiedMatches(tied_col)

print(count, "captians has atleast 1",col_name ,"match")
