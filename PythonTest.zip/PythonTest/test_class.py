import pandas as pd
import csv


class TestClass:
    filename = "captains.txt"
    col_name_one = "name"
    col_name_two = "tied"

    def read_col(self, file_name, col_name, col_type):
        matches = list()
        with open(file_name) as FH:
            rows = csv.reader(FH)
            headers = next(rows)
            col_idx = headers.index(col_name)
            for row in rows:
                tiedMatches = col_type(row[col_idx])
                matches.append(tiedMatches)
        return matches

    def test_TC01(self):
        print("test_TC01")
        tied_col = self.read_col(self.filename, self.col_name_two, str)
        Tied_dataframe = pd.DataFrame(list(tied_col), columns=['Tied'])
        Atleastone_Tiedmatch = Tied_dataframe[Tied_dataframe['Tied'] > '0']
        expected= 3
        actual = len(Atleastone_Tiedmatch)
        assert actual == expected

    def test_TC02(self):
        print("test_TC02")
        names_col = self.read_col(self.filename, self.col_name_one, str)
        tied_col = self.read_col(self.filename, self.col_name_two, str)
        
        mydf = pd.DataFrame(list(zip(names_col, tied_col)), columns=['Player_Name', 'Tied'])
        mydf = mydf.sort_values(by=['Tied'], ascending=False)
        Atleastone_Tiedmatch = mydf[mydf['Tied'] > '0']
        captains_names = Atleastone_Tiedmatch['Player_Name'].tolist()
        expected= "MS Dhoni"
        actual = captains_names[0]
        assert actual == expected
              
