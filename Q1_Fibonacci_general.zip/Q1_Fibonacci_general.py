# Program to display the Fibonacci numbers first 9 series.


fibonacciSeries = int(input("Enter the number of Fibonacci series ?"))
 
a = 0
b = 1
c, count = 0, 0 

print(a)
print(b)
while count < (fibonacciSeries-2):
    c = a + b
    a = b
    b = c
    print(c)
    count+= 1
    
